Place your local images here and update HTML paths if you want offline images.
